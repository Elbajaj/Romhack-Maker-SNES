hi thanks for downloading this romhacking guide



Lunar magic:

Make SMW levels



Flips:
Patch Them



HxD32:
Hex Editor



CFG editor:
Change Behaviors